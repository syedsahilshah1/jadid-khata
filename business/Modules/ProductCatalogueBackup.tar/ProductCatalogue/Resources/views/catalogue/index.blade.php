@extends('layouts.guest')
@section('title', $business->name)

@section('content')
<style>
    .cart-icon-link {
        position: relative;
        overflow: visible; /* allow badge to sit outside without covering icon */
    }
    .cart-badge {
        position: absolute;
        top: 0;
        right: 0;
        transform: translate(40%, -40%);
        z-index: 2;
        min-width: 18px;
        padding: 0 5px;
        border-radius: 9999px;
        font-size: 11px;
        height: 18px;
        line-height: 18px;
        text-align: center;
        pointer-events: none;
    }
    #send-order-whatsapp-btn {
        background-color: #25D366;
        border-color: #25D366;
    }
    #send-order-whatsapp-btn:hover {
        background-color: #20BA5A;
        border-color: #20BA5A;
    }
    /* Quantity selector alignment */
    /* Cart total amount highlight */
    .cart-total-amount {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 4px;
        padding: 4px 8px;
        font-weight: 600;
        color: #28a745 !important;
    }
    /* Hide number input spinners */
    .product-quantity::-webkit-inner-spin-button,
    .product-quantity::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    .product-quantity[type=number] {
        -moz-appearance: textfield;
    }
    /* Ensure input-group works with flex and prevents stacking */
    .input-group {
        display: inline-flex !important;
        flex-direction: row !important;
        align-items: stretch !important;
    }
    .input-group .btn-minus,
    .input-group .btn-plus,
    .input-group .product-quantity {
        display: inline-flex !important;
        vertical-align: top !important;
    }
    
    /* Smooth fade-in animation for product cards */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    .tw-animate-fade-in {
        animation: fadeIn 0.35s ease-out forwards;
    }

    /* Premium-calm: avoid stagger/bounce animations */
    
    /* Premium-calm: avoid scaling interactions on steppers */
    
    /* Product card images: force consistent box size + cover fill
       Fixes cases where wrapper height collapses to 0 (img present but invisible)
       and cases where object-fit: contain makes image look tiny. */
    .product-box .product-image-wrap {
        /* Use !important to prevent any cascade/inline collapse */
        height: 11rem !important;
        min-height: 11rem !important;
        max-height: 11rem !important;
        overflow: hidden !important;
        flex: 0 0 auto;
    }
    @media (min-width: 640px) {
        .product-box .product-image-wrap {
            height: 12rem !important;
            min-height: 12rem !important;
            max-height: 12rem !important;
        }
    }
    .product-box .product-image-wrap > a {
        display: block;
        width: 100%;
        height: 100%;
    }
    .product-box .product-image-wrap img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    /* Card hover lift handled via utility classes */
    
    /* Hide number input spinners for cart quantity */
    .cart-item-quantity::-webkit-inner-spin-button,
    .cart-item-quantity::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    .cart-item-quantity[type=number] {
        -moz-appearance: textfield;
    }
    
    /* DaisyUI Input Group Styling - Clear and Visible */
    .tw-dw-input-group {
        display: flex;
        align-items: stretch;
        width: 100%;
    }
    .tw-dw-input-group > span {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 1.25rem;
        border-radius: 0.75rem 0 0 0.75rem;
        min-width: 3.5rem;
        height: 3rem;
        flex-shrink: 0;
    }
    .tw-dw-input-group > .tw-dw-input,
    .tw-dw-input-group > .tw-dw-textarea {
        border-left: none !important;
        border-radius: 0 0.75rem 0.75rem 0 !important;
        flex: 1;
        padding-left: 1rem;
        padding-right: 1rem;
    }
    .tw-dw-input-group > .tw-dw-textarea {
        border-top-left-radius: 0 !important;
        padding-top: 0.75rem;
    }
    .tw-dw-input-group.tw-items-start > span {
        align-items: flex-start;
        padding-top: 0.875rem;
        height: auto;
        min-height: 100px;
    }
    .tw-dw-input-group.tw-items-start > .tw-dw-textarea {
        border-top-left-radius: 0 !important;
    }
    /* Ensure input borders are visible */
    .tw-dw-input-group .tw-dw-input:focus,
    .tw-dw-input-group .tw-dw-textarea:focus {
        border-color: rgb(59 130 246) !important;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
    }

    /* Horizontal chips nav: hide scrollbar (minimal look) */
    .no-scrollbar::-webkit-scrollbar {
        display: none;
    }
    .no-scrollbar {
        -ms-overflow-style: none; /* IE and Edge */
        scrollbar-width: none; /* Firefox */
    }

    /* Chips nav subtle state when scrolled */
    #catalogueNav.is-scrolled {
        background: rgba(255, 255, 255, 0.92);
        border-color: rgba(229, 231, 235, 1);
        box-shadow: 0 1px 0 rgba(17, 24, 39, 0.04);
    }

    /*
      Fixed fallback + z-index discipline:
      Bootstrap modal backdrop is ~1040 and modal is ~1050.
      Keep catalogue nav below those so it never overlays modals.
    */
    #catalogueNavWrap.is-fixed {
        position: fixed !important;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1030;
    }
</style>
@if($enable_whatsapp_ordering == 1)
<div class="tw-dw-drawer tw-dw-drawer-end">
    <input id="cartDrawer" type="checkbox" class="tw-dw-drawer-toggle" />
    <div class="tw-dw-drawer-content">
@endif
<!-- Content Header (Page header) -->
<section class="tw-py-6 sm:tw-py-8 tw-px-4 tw-bg-gradient-to-br tw-from-primary-50 tw-via-white tw-to-gray-50 tw-shadow-sm" id="top">
    <div class="tw-max-w-7xl tw-mx-auto">
        <div class="tw-rounded-3xl tw-border tw-border-gray-200/70 tw-bg-white/70 tw-backdrop-blur tw-shadow-[0_12px_30px_rgba(0,0,0,0.08)] tw-px-5 sm:tw-px-7 tw-py-5 sm:tw-py-6">
            <div class="tw-grid tw-grid-cols-1 md:tw-grid-cols-3 tw-items-center tw-gap-5">
                <!-- Left: Business name -->
                <div class="tw-order-2 md:tw-order-1 tw-text-center md:tw-text-left">
                    <h2 class="tw-text-2xl sm:tw-text-3xl md:tw-text-4xl lg:tw-text-5xl tw-font-extrabold tw-text-gray-900 tw-tracking-tight tw-leading-tight">
                        {{$business->name}}
                    </h2>
                </div>

                <!-- Center: Logo -->
                <div class="tw-order-1 md:tw-order-2 tw-flex tw-justify-center">
                    <div class="tw-relative">
                        <div class="tw-absolute -tw-inset-3 tw-rounded-full tw-bg-primary-200/30 tw-blur-xl"></div>
                        @if(!empty($business->logo))
                            <img
                                src="{{ asset('uploads/business_logos/' . $business->logo) }}"
                                alt="{{ $business->name }} logo"
                                class="tw-relative tw-w-20 tw-h-20 sm:tw-w-24 sm:tw-h-24 tw-object-contain tw-rounded-full tw-bg-white tw-shadow-md tw-ring-4 tw-ring-white"
                            >
                        @else
                            <div class="tw-relative tw-w-20 tw-h-20 sm:tw-w-24 sm:tw-h-24 tw-rounded-full tw-bg-white tw-shadow-md tw-ring-4 tw-ring-white tw-flex tw-items-center tw-justify-center">
                                <i class="fas fa-store tw-text-3xl sm:tw-text-4xl tw-text-primary-700"></i>
                            </div>
                        @endif
                    </div>
                </div>

                <!-- Right: Location name + address -->
                <div class="tw-order-3 tw-text-center md:tw-text-right">
                    <div class="tw-inline-flex tw-items-center tw-justify-center md:tw-justify-end tw-gap-2 tw-text-base sm:tw-text-lg md:tw-text-xl tw-font-semibold tw-text-gray-800">
                        <i class="fas fa-map-marker-alt tw-text-primary-600"></i>
                        {{$business_location->name}}
                    </div>
                    <div class="tw-mt-1 tw-text-sm sm:tw-text-base md:tw-text-lg tw-text-gray-600 tw-leading-relaxed">
                        {!! $business_location->location_address !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="catalogueNavWrap" class="no-print tw-bg-white/70 tw-backdrop-blur" style="position: sticky; top: 0; z-index: 1030;">
    <div class="tw-max-w-7xl tw-mx-auto tw-px-4">
        <nav id="catalogueNav" class="tw-transition-all tw-duration-200 tw-rounded-2xl tw-border tw-border-gray-200 tw-bg-white/90 tw-backdrop-blur tw-mt-2 tw-mb-2">
            <div class="tw-flex tw-items-center tw-gap-3 tw-px-3 tw-py-3">
                <!-- Back to top -->
                <a class="menu tw-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-rounded-xl tw-bg-white tw-border tw-border-gray-200 tw-shadow-sm hover:tw-shadow tw-transition"
                   href="#top" aria-label="Back to top">
                    @if(!empty($business->logo))
                        <img src="{{asset( 'uploads/business_logos/' . $business->logo)}}" alt="Logo" class="tw-w-6 tw-h-6 tw-object-contain">
                    @else
                        <i class="fas fa-boxes tw-text-gray-700"></i>
                    @endif
                </a>

                <!-- Category chips -->
                <div class="tw-flex-1 tw-overflow-x-auto no-scrollbar">
                    <div class="tw-flex tw-items-center tw-gap-2 tw-whitespace-nowrap tw-px-1">
                        @foreach($categories as $key => $value)
                            <a href="#category{{$key}}"
                               class="menu tw-inline-flex tw-items-center tw-h-9 tw-px-3 tw-rounded-full tw-border tw-border-gray-200 tw-bg-white tw-text-sm tw-font-medium tw-text-gray-700 hover:tw-border-gray-300 hover:tw-bg-gray-50 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-2 tw-transition">
                                {{$value}}
                            </a>
                        @endforeach
                        <a href="#category0"
                           class="menu tw-inline-flex tw-items-center tw-h-9 tw-px-3 tw-rounded-full tw-border tw-border-gray-200 tw-bg-white tw-text-sm tw-font-medium tw-text-gray-700 hover:tw-border-gray-300 hover:tw-bg-gray-50 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-2 tw-transition">
                            Uncategorized
                        </a>
                    </div>
                </div>

                <!-- Cart -->
                @if($enable_whatsapp_ordering == 1)
                    <div class="tw-flex tw-items-center tw-gap-3 tw-pl-1">
                        <span class="cart-total-amount" id="cart-total-amount" style="display: none; font-size: 12px; white-space: nowrap;">0</span>
                        <label for="cartDrawer" role="button" class="cart-icon-link tw-cursor-pointer tw-relative tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-rounded-xl tw-bg-white tw-border tw-border-gray-200 tw-shadow-sm hover:tw-shadow tw-transition"
                           id="cart-icon" aria-label="Open cart">
                            <i class="fas fa-shopping-cart tw-text-gray-800"></i>
                            <span class="badge badge-danger cart-badge" id="cart-badge" style="display: none;">0</span>
                        </label>
                    </div>
                @endif
            </div>
        </nav>
    </div>
</section>
<div id="catalogueNavSpacer" class="no-print" style="display:none;"></div>
<!-- Main content -->
<section class="content tw-pt-0 tw-bg-gray-50">
    <div class="tw-max-w-7xl tw-mx-auto tw-px-4 tw-py-8">
        @foreach($products as $product_category)
            <!-- Category Header -->
            <div class="tw-mb-8 tw-mt-12 first:tw-mt-0">
                <h2 class="tw-text-2xl sm:tw-text-3xl md:tw-text-4xl tw-font-bold tw-text-gray-900 tw-border-b-2 tw-border-primary-500 tw-pb-3 tw-inline-block" id="category{{$product_category->first()->category->id ?? 0}}">
                    {{$product_category->first()->category->name ?? 'Uncategorized'}}
                </h2>
            </div>

            <!-- Product Grid -->
            <div class="tw-grid tw-grid-cols-1 sm:tw-grid-cols-2 lg:tw-grid-cols-4 xl:tw-grid-cols-4 2xl:tw-grid-cols-4 tw-gap-4 sm:tw-gap-5 lg:tw-gap-6 tw-mb-12">
            @foreach($product_category as $product)
                @php
                   
                    $max_price = $product->variations->max('sell_price_inc_tax');
                    $min_price = $product->variations->min('sell_price_inc_tax');
                    $is_out_of_stock = ($product->stock < 0 || empty($product->stock)) && $product->enable_stock;
                @endphp

                <!-- Product Card -->
                <div class="tw-dw-card tw-bg-base-100 tw-shadow-sm hover:tw-shadow-md tw-transition-all tw-duration-200 tw-rounded-2xl tw-overflow-hidden tw-border tw-border-gray-200 hover:tw-border-primary-300 product-box tw-flex tw-flex-col tw-animate-fade-in tw-transform hover:-tw-translate-y-0.5">
                   
                    <!-- Product Image -->
                    <div class="product-image-wrap tw-relative tw-bg-gray-50 tw-h-[11rem] sm:tw-h-[12rem] tw-overflow-hidden">
                        <a href="#"
                           class="show-product-details tw-block tw-w-full tw-h-full"
                           aria-label="{{ $product->name }}"
                           data-href="{{action([\Modules\ProductCatalogue\Http\Controllers\ProductCatalogueController::class, 'show'],  [$business->id, $product->id])}}?location_id={{$business_location->id}}">
                            <img src="{{ $product->image_url }}"
                                 alt="{{ $product->name }}"
                                 loading="lazy"
                                 onerror="this.onerror=null;this.src='{{ asset('/img/default.png') }}';"
                                 class="tw-w-full tw-h-full tw-object-cover tw-block tw-transition-transform tw-duration-300 hover:tw-scale-105">
                        </a>

                        @if($is_out_of_stock)
                            <span class="tw-absolute tw-top-3 tw-left-3 tw-inline-flex tw-items-center tw-rounded-full tw-bg-red-600 tw-text-white tw-text-xs tw-font-bold tw-px-3 tw-py-1 tw-shadow">
                                @lang('productcatalogue::lang.out_of_stock')
                            </span>
                        @endif
                    </div>

                    <!-- Card Body -->
                    <div class="tw-dw-card-body tw-flex-1 tw-flex tw-flex-col tw-p-5 tw-bg-white">
                        <!-- Product Title -->
                        <h2 class="tw-dw-card-title tw-text-lg tw-font-semibold tw-text-gray-900 tw-mb-3 tw-line-clamp-2 tw-min-h-[3.5rem] tw-group/title">
                            <a href="#" class="show-product-details tw-text-gray-900 hover:tw-text-primary-600 tw-transition-all tw-duration-200 tw-no-underline tw-inline-block tw-transform hover:tw-translate-x-1" data-href="{{action([\Modules\ProductCatalogue\Http\Controllers\ProductCatalogueController::class, 'show'],  [$business->id, $product->id])}}?location_id={{$business_location->id}}">
                                {{$product->name}}
                            </a>
                        </h2>

                        <!-- Product Info -->
                        <div class="tw-space-y-3 tw-mb-4 tw-pr-1">
                            <!-- Price -->
                            <div class="tw-bg-gray-50 tw-p-3 tw-rounded-lg tw-border tw-border-gray-200">
                                <div class="tw-flex tw-items-baseline tw-gap-2 tw-flex-wrap">
                                    <!-- <span class="tw-text-xs tw-text-gray-500 tw-font-medium tw-uppercase tw-tracking-wide">@lang('lang_v1.price')</span> -->
                                    <div class="tw-flex tw-items-baseline tw-gap-2 tw-flex-wrap">
                                        <span class="display_currency tw-text-2xl tw-font-bold tw-text-primary-600 tw-tracking-tight" data-currency_symbol="true">{{($max_price)}}</span>
                                        @if($max_price != $min_price)
                                            <span class="tw-text-gray-400 tw-text-lg">-</span>
                                            <span class="display_currency tw-text-2xl tw-font-bold tw-text-primary-600 tw-tracking-tight" data-currency_symbol="true">{{($min_price)}}</span>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <!-- SKU -->
                            <div class="tw-hidden md:tw-flex tw-items-center tw-gap-2 tw-text-xs">
                                <span class="tw-text-gray-400 tw-font-medium">
                                    <i class="fas fa-barcode tw-mr-1 tw-text-gray-400"></i>@lang('product.sku'):
                                </span>
                                <span class="tw-text-gray-700 tw-font-mono tw-bg-white tw-px-2 tw-py-1 tw-rounded tw-border tw-border-gray-200">{{$product->sku}}</span>
                            </div>

                            <!-- Variable Product Variations -->
                            @if($product->type == 'variable')
                                @php
                                    $variations = $product->variations->groupBy('product_variation_id');
                                @endphp
                                @foreach($variations as $product_variation)
                                    <div class="tw-mt-3">
                                        <label class="tw-text-xs tw-text-gray-600 tw-font-semibold tw-block tw-mb-2 tw-uppercase tw-tracking-wide">
                                            {{$product_variation->first()->product_variation->name}}
                                        </label>
                                        <div class="tw-relative">
                                            <select class="tw-w-full tw-px-3 tw-py-2 tw-pr-10 tw-text-sm tw-font-medium tw-text-gray-900 tw-bg-white tw-border tw-border-gray-200 tw-rounded-lg tw-shadow-none focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-border-primary-500 tw-transition-all tw-cursor-pointer hover:tw-border-gray-300 tw-appearance-none tw-bg-no-repeat tw-bg-right tw-bg-[length:1.25em_1.25em] tw-bg-[right_0.75rem_center]" style="background-image: url('data:image/svg+xml;charset=UTF-8,%3csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23374151%27 stroke-width=%272%27 stroke-linecap=%27round%27 stroke-linejoin=%27round%27%3e%3cpolyline points=%276 9 12 15 18 9%27%3e%3c/polyline%3e%3c/svg%3e');">
                                                @foreach($product_variation as $variation)
                                                    <option value="{{$variation->id}}">
                                                        {{$variation->name}} ({{$variation->sub_sku}}) - <span class="display_currency" data-currency_symbol="true">{{($variation->sell_price_inc_tax)}}</span>
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                        </div>

                        <!-- Quantity Controls or View Options Button -->
                        @if($product->type == 'single' || $product->type == 'combo')
                            @if($enable_whatsapp_ordering == 1)
                                @php
                                    $variation = $product->variations->first();
                                @endphp
                                <div class="add-to-cart-section tw-mt-auto tw-pt-4 tw-flex tw-justify-center">
                                    <!-- Quantity Control Button Group -->
                                    <div class="input-group tw-inline-flex tw-items-stretch tw-justify-center tw-gap-0 tw-bg-white tw-rounded-lg tw-p-1 tw-border tw-border-gray-200 tw-shadow-sm hover:tw-shadow-md tw-transition-all tw-duration-200">
                                        <button class="btn-minus tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-bg-transparent tw-text-gray-700 tw-rounded-md hover:tw-bg-gray-50 hover:tw-text-gray-900 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-1 tw-transition disabled:tw-opacity-50 disabled:tw-cursor-not-allowed disabled:hover:tw-bg-transparent" 
                                                type="button" 
                                                data-product-id="{{$product->id}}" 
                                                data-variation-id="{{$variation->id}}"
                                                aria-label="Decrease quantity"
                                                @if($is_out_of_stock) disabled @endif>
                                            <i class="fas fa-minus"></i>
                                        </button>
                                        
                                        <input type="number" 
                                               class="product-quantity tw-w-14 tw-h-10 tw-text-center tw-font-semibold tw-text-gray-900 tw-bg-transparent tw-border-x tw-border-gray-200 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-1 tw-text-sm tw-appearance-none tw-flex-shrink-0 tw-transition" 
                                               value="0" 
                                               min="0" 
                                               inputmode="numeric"
                                               data-product-id="{{$product->id}}" 
                                               data-variation-id="{{$variation->id}}" 
                                               data-product-name="{{$product->name}}" 
                                               data-variation-name="" 
                                               data-price="{{$variation->sell_price_inc_tax}}" 
                                               data-image="{{$product->image_url}}" 
                                               data-sku="{{$variation->sub_sku}}"
                                               @if($is_out_of_stock) disabled @endif>
                                        
                                        <button class="btn-plus tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-bg-transparent tw-text-gray-700 tw-rounded-md hover:tw-bg-gray-50 hover:tw-text-gray-900 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-1 tw-transition disabled:tw-opacity-50 disabled:tw-cursor-not-allowed disabled:hover:tw-bg-transparent" 
                                                type="button" 
                                                data-product-id="{{$product->id}}" 
                                                data-variation-id="{{$variation->id}}"
                                                aria-label="Increase quantity"
                                                @if($is_out_of_stock) disabled @endif>
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </div>
                            @endif
                        @else
                            <div class="tw-mt-auto tw-pt-4">
                                <a href="#" 
                                   role="button"
                                   aria-label="View options"
                                   class="show-product-details tw-w-full tw-inline-flex tw-items-center tw-justify-center tw-gap-2 tw-px-6 tw-py-3.5 tw-bg-gradient-to-r tw-from-primary-600 tw-to-primary-700 tw-text-white tw-font-semibold tw-rounded-xl tw-shadow-md hover:tw-shadow-xl hover:tw-from-primary-700 hover:tw-to-primary-800 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-2 tw-transition-all tw-duration-300 tw-no-underline tw-transform hover:tw-scale-[1.02] active:tw-scale-[0.98] tw-group" 
                                   data-href="{{action([\Modules\ProductCatalogue\Http\Controllers\ProductCatalogueController::class, 'show'],  [$business->id, $product->id])}}?location_id={{$business_location->id}}">
                                    <i class="fas fa-eye tw-transition-transform tw-duration-300 group-hover:tw-rotate-12"></i>
                                    <span class="tw-inline-flex tw-items-center tw-gap-2">
                                        <span>View Options</span>
                                        <i class="fas fa-arrow-right tw-text-sm tw-w-0 tw-overflow-hidden tw-opacity-0 tw-transition-all tw-duration-300 group-hover:tw-w-4 group-hover:tw-opacity-100 group-hover:tw-translate-x-1"></i>
                                    </span>
                                </a>
                            </div>
                        @endif
                    </div>
                </div>
            @endforeach
            </div>
        @endforeach
    </div>
    
    <!-- Scroll to Top Button -->
    <div class='scrolltop no-print tw-fixed tw-bottom-8 tw-right-8 tw-z-50'>
        <button class='tw-btn tw-btn-circle tw-btn-primary tw-shadow-lg hover:tw-scale-110 tw-transition-transform tw-duration-300 scroll icon tw-w-14 tw-h-14'>
            <i class="fas fa-angle-up tw-text-xl"></i>
        </button>
    </div>
</section>
<!-- /.content -->
<!-- Add currency related field-->
<input type="hidden" id="__code" value="{{$business->currency->code}}">
<input type="hidden" id="__symbol" value="{{$business->currency->symbol}}">
<input type="hidden" id="__thousand" value="{{$business->currency->thousand_separator}}">
<input type="hidden" id="__decimal" value="{{$business->currency->decimal_separator}}">
<input type="hidden" id="__symbol_placement" value="{{$business->currency->currency_symbol_placement}}">
<input type="hidden" id="__precision" value="{{$business->currency_precision}}">
<input type="hidden" id="__quantity_precision" value="{{$business->quantity_precision}}">
<input type="hidden" id="__whatsapp_number" value="{{$order_receiving_whatsapp_number ?? ''}}">
<input type="hidden" id="__catalogue_csrf_token" value="{{csrf_token()}}">
<input type="hidden" id="__catalogue_order_url" value="{{$catalogue_order_url ?? ''}}">
<input type="hidden" id="__catalogue_login_url" value="{{$login_url ?? url('/login')}}">
<input type="hidden" id="__catalogue_dashboard_url" value="{{$customer_dashboard_url ?? url('/contact/order-request')}}">
<input type="hidden" id="__enable_whatsapp_ordering" value="{{$enable_whatsapp_ordering}}">

<!-- Product Catalogue JS translations (from module language files) -->
<script type="text/javascript">
    window.LANG = window.LANG || {};
    Object.assign(window.LANG, {
        productcatalogue_cart_empty: @json(__('productcatalogue::lang.cart_empty')),
        productcatalogue_whatsapp_not_configured: @json(__('productcatalogue::lang.whatsapp_not_configured')),
        productcatalogue_order_sent_successfully: @json(__('productcatalogue::lang.order_sent_successfully')),
        productcatalogue_please_enter_name: @json(__('productcatalogue::lang.please_enter_name')),
        productcatalogue_please_enter_email: @json(__('productcatalogue::lang.please_enter_email')),
        productcatalogue_please_enter_valid_email: @json(__('productcatalogue::lang.please_enter_valid_email')),
        productcatalogue_please_enter_phone: @json(__('productcatalogue::lang.please_enter_phone')),
        productcatalogue_please_enter_address: @json(__('productcatalogue::lang.please_enter_address')),
        productcatalogue_your_cart_is_empty: @json(__('productcatalogue::lang.your_cart_is_empty')),
        productcatalogue_product: @json(__('productcatalogue::lang.product')),
        productcatalogue_price: @json(__('productcatalogue::lang.price')),
        productcatalogue_quantity: @json(__('productcatalogue::lang.quantity')),
        productcatalogue_subtotal_label: @json(__('productcatalogue::lang.subtotal_label')),
        productcatalogue_sku: @json(__('productcatalogue::lang.sku')),
        productcatalogue_action: @json(__('productcatalogue::lang.action')),
        productcatalogue_confirm_remove_from_cart: @json(__('productcatalogue::lang.productcatalogue_confirm_remove_from_cart')),
    });
</script>

<div class="modal fade product_modal" tabindex="-1" role="dialog" 
    aria-labelledby="gridSystemModalLabel">
</div>

<!-- Cart Drawer (DaisyUI) is rendered after scripts -->
@if($enable_whatsapp_ordering == 1)
    </div>

    <div class="tw-dw-drawer-side tw-z-[1060]" aria-label="Cart drawer">
        <label for="cartDrawer" class="tw-dw-drawer-overlay"></label>

        <aside class="tw-bg-white tw-w-full lg:tw-w-1/2 tw-h-full tw-shadow-2xl tw-flex tw-flex-col">
            <!-- Cart view -->
            <div id="cart-drawer-view" class="tw-flex tw-flex-col tw-h-full">
                <div class="tw-flex tw-items-center tw-justify-between tw-px-5 tw-py-4 tw-bg-gradient-to-r tw-from-primary-600 tw-to-primary-700 tw-text-white tw-border-0">
                    <h4 class="tw-m-0 tw-text-white tw-font-bold tw-text-lg tw-flex tw-items-center">
                        <i class="fas fa-shopping-cart tw-mr-2"></i> {{ __('productcatalogue::lang.my_cart') }}
                    </h4>
                    <label for="cartDrawer" role="button" class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-rounded-lg hover:tw-bg-white/10 tw-transition tw-cursor-pointer" aria-label="Close cart">
                        <span aria-hidden="true" class="tw-text-2xl">&times;</span>
                    </label>
                </div>

                <div class="tw-flex-1 tw-overflow-y-auto tw-p-5">
                    <div id="cart-items-container">
                        <div class="tw-text-center tw-py-12">
                            <i class="fas fa-shopping-cart tw-text-6xl tw-text-gray-300 tw-mb-4"></i>
                            <p class="tw-text-gray-500 tw-text-lg tw-font-medium">{{ __('productcatalogue::lang.your_cart_is_empty') }}</p>
                        </div>
                    </div>

                    <div id="cart-summary" style="display: none;">
                        <div class="tw-mt-6 tw-pt-6 tw-border-t-2 tw-border-gray-200">
                            <div class="tw-flex tw-justify-end">
                                <div class="tw-w-full md:tw-w-96 tw-bg-gradient-to-br tw-from-gray-50 tw-to-gray-100 tw-rounded-xl tw-p-6 tw-shadow-md">
                                    <div class="tw-space-y-3">
                                        <div class="tw-flex tw-justify-between tw-items-center tw-text-gray-700">
                                            <span class="tw-font-semibold">{{ __('productcatalogue::lang.subtotal') }}:</span>
                                            <span class="tw-font-bold tw-text-lg" id="cart-subtotal">0</span>
                                        </div>
                                        <div class="tw-border-t-2 tw-border-gray-300 tw-pt-3 tw-flex tw-justify-between tw-items-center">
                                            <span class="tw-font-bold tw-text-lg tw-text-gray-900">{{ __('productcatalogue::lang.total') }}:</span>
                                            <span class="tw-font-bold tw-text-2xl tw-text-primary-600" id="cart-total">0</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tw-bg-gray-50 tw-border-t tw-border-gray-200 tw-px-5 tw-py-4 tw-flex tw-flex-col sm:tw-flex-row tw-gap-3" id="cart-footer" style="display: none;">
                    <label for="cartDrawer" role="button" class="tw-flex-1 tw-cursor-pointer tw-px-6 tw-py-3 tw-bg-white tw-text-gray-700 tw-border-2 tw-border-gray-300 tw-rounded-xl tw-font-semibold hover:tw-bg-gray-50 hover:tw-border-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-gray-500 focus:tw-ring-offset-2 tw-transition-all tw-duration-200 tw-flex tw-items-center tw-justify-center">
                        <i class="fas fa-arrow-left tw-mr-2"></i>{{ __('productcatalogue::lang.continue_shopping') }}
                    </label>
                    <button type="button" class="tw-flex-1 tw-px-6 tw-py-3 tw-bg-gradient-to-r tw-from-primary-600 tw-to-primary-700 tw-text-white tw-rounded-xl tw-font-semibold tw-shadow-md hover:tw-shadow-lg hover:tw-from-primary-700 hover:tw-to-primary-800 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-ring-offset-2 tw-transition-all tw-duration-200 tw-transform hover:tw-scale-105 tw-flex tw-items-center tw-justify-center" id="place-order-btn">
                        <i class="fas fa-shopping-bag tw-mr-2"></i>{{ __('productcatalogue::lang.place_order') }}
                    </button>
                </div>
            </div>

            <!-- Order view (inside drawer) -->
            <div id="order-drawer-view" class="tw-hidden tw-flex tw-flex-col tw-h-full">
                <div class="tw-flex tw-items-center tw-justify-between tw-px-5 tw-py-4 tw-bg-gradient-to-r tw-from-green-600 tw-to-green-700 tw-text-white tw-border-0">
                    <div class="tw-flex tw-items-center tw-gap-3">
                        <button type="button" class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-rounded-lg hover:tw-bg-white/10 tw-transition" id="back-to-cart-btn" aria-label="Back to cart">
                            <i class="fas fa-arrow-left"></i>
                        </button>
                        <h4 class="tw-m-0 tw-text-white tw-font-bold tw-text-lg tw-flex tw-items-center">
                            <i class="fas fa-shopping-bag tw-mr-2"></i> {{ __('productcatalogue::lang.place_your_order') }}
                        </h4>
                    </div>
                    <label for="cartDrawer" role="button" class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-rounded-lg hover:tw-bg-white/10 tw-transition tw-cursor-pointer" aria-label="Close order">
                        <span aria-hidden="true" class="tw-text-2xl">&times;</span>
                    </label>
                </div>

                <div class="tw-flex-1 tw-overflow-y-auto tw-p-5">
                    <!-- Order Summary -->
                    <div class="tw-bg-gradient-to-br tw-from-gray-50 tw-to-gray-100 tw-p-5 tw-mb-6 tw-rounded-xl tw-shadow-md tw-border tw-border-gray-200">
                        <h5 class="tw-mb-4 tw-font-bold tw-text-lg tw-text-gray-900">
                            <i class="fas fa-list tw-mr-2 tw-text-primary-600"></i> {{ __('productcatalogue::lang.order_summary') }}
                        </h5>
                        <div id="order-summary-items" class="table-responsive">
                            <!-- Will be populated by JavaScript -->
                        </div>
                        <div class="tw-text-right tw-mt-4 tw-pt-4 tw-border-t-2 tw-border-gray-300">
                            <span class="tw-text-gray-700 tw-font-semibold tw-text-lg tw-mr-2">{{ __('productcatalogue::lang.total') }}:</span>
                            <strong class="tw-text-2xl tw-font-bold tw-text-primary-600" id="order-total-display">0</strong>
                        </div>
                    </div>

                    <div class="tw-h-px tw-bg-gradient-to-r tw-from-transparent tw-via-gray-300 tw-to-transparent tw-my-6"></div>

                    <!-- Customer Details Form -->
                    <h5 class="tw-mb-4 tw-font-bold tw-text-lg tw-text-gray-900">
                        <i class="fas fa-user tw-mr-2 tw-text-primary-600"></i> {{ __('productcatalogue::lang.customer_details') }}
                    </h5>
                    <form id="order-form">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group tw-mb-5">
                                    <label for="customer_name" class="tw-dw-label tw-mb-3">
                                        <span class="tw-dw-label-text tw-text-sm tw-font-bold tw-text-gray-800 tw-uppercase tw-tracking-wide">
                                            {{ __('productcatalogue::lang.your_name') }} <span class="tw-text-red-500">*</span>
                                        </span>
                                    </label>
                                    <label class="tw-dw-input-group tw-shadow-sm">
                                        <span class="tw-bg-primary-500 tw-text-white tw-border-2 tw-border-primary-500 tw-font-semibold">
                                            <i class="fas fa-user tw-text-base"></i>
                                        </span>
                                        <input type="text" class="tw-dw-input tw-dw-input-bordered tw-w-full tw-h-12 tw-border-2 tw-border-gray-300 tw-bg-white tw-text-gray-900 tw-placeholder-gray-400 focus:tw-outline-none focus:tw-border-primary-500 focus:tw-ring-2 focus:tw-ring-primary-200 tw-transition-all" id="customer_name" name="customer_name" required placeholder="{{ __('productcatalogue::lang.enter_your_name') }}">
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group tw-mb-5">
                                    <label for="customer_email" class="tw-dw-label tw-mb-3">
                                        <span class="tw-dw-label-text tw-text-sm tw-font-bold tw-text-gray-800 tw-uppercase tw-tracking-wide">
                                            {{ __('productcatalogue::lang.email_address') }} <span class="tw-text-red-500">*</span>
                                        </span>
                                    </label>
                                    <label class="tw-dw-input-group tw-shadow-sm">
                                        <span class="tw-bg-primary-500 tw-text-white tw-border-2 tw-border-primary-500 tw-font-semibold">
                                            <i class="fas fa-envelope tw-text-base"></i>
                                        </span>
                                        <input type="email" class="tw-dw-input tw-dw-input-bordered tw-w-full tw-h-12 tw-border-2 tw-border-gray-300 tw-bg-white tw-text-gray-900 tw-placeholder-gray-400 focus:tw-outline-none focus:tw-border-primary-500 focus:tw-ring-2 focus:tw-ring-primary-200 tw-transition-all" id="customer_email" name="customer_email" required placeholder="{{ __('productcatalogue::lang.enter_your_email') }}">
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group tw-mb-5">
                                    <label for="customer_phone" class="tw-dw-label tw-mb-3">
                                        <span class="tw-dw-label-text tw-text-sm tw-font-bold tw-text-gray-800 tw-uppercase tw-tracking-wide">
                                            {{ __('productcatalogue::lang.phone_number') }} <span class="tw-text-red-500">*</span>
                                        </span>
                                    </label>
                                    <label class="tw-dw-input-group tw-shadow-sm">
                                        <span class="tw-bg-primary-500 tw-text-white tw-border-2 tw-border-primary-500 tw-font-semibold">
                                            <i class="fas fa-phone tw-text-base"></i>
                                        </span>
                                        <input type="tel" class="tw-dw-input tw-dw-input-bordered tw-w-full tw-h-12 tw-border-2 tw-border-gray-300 tw-bg-white tw-text-gray-900 tw-placeholder-gray-400 focus:tw-outline-none focus:tw-border-primary-500 focus:tw-ring-2 focus:tw-ring-primary-200 tw-transition-all" id="customer_phone" name="customer_phone" required placeholder="{{ __('productcatalogue::lang.enter_your_phone_number') }}">
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group tw-mb-5">
                                    <label for="delivery_address" class="tw-dw-label tw-mb-3">
                                        <span class="tw-dw-label-text tw-text-sm tw-font-bold tw-text-gray-800 tw-uppercase tw-tracking-wide">
                                            {{ __('productcatalogue::lang.delivery_address') }} <span class="tw-text-red-500">*</span>
                                        </span>
                                    </label>
                                    <label class="tw-dw-input-group tw-items-start tw-shadow-sm">
                                        <span class="tw-bg-primary-500 tw-text-white tw-border-2 tw-border-primary-500 tw-font-semibold tw-py-3">
                                            <i class="fas fa-map-marker-alt tw-text-base"></i>
                                        </span>
                                        <textarea class="tw-dw-textarea tw-dw-textarea-bordered tw-w-full tw-min-h-[100px] tw-border-2 tw-border-gray-300 tw-bg-white tw-text-gray-900 tw-placeholder-gray-400 focus:tw-outline-none focus:tw-border-primary-500 focus:tw-ring-2 focus:tw-ring-primary-200 tw-transition-all tw-resize-none" id="delivery_address" name="delivery_address" rows="3" required placeholder="{{ __('productcatalogue::lang.enter_your_delivery_address') }}"></textarea>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="tw-bg-gray-50 tw-border-t tw-border-gray-200 tw-px-5 tw-py-4 tw-flex tw-flex-col sm:tw-flex-row tw-gap-3">
                    <button type="button" class="tw-flex-1 tw-px-6 tw-py-3 tw-bg-white tw-text-gray-700 tw-border-2 tw-border-gray-300 tw-rounded-xl tw-font-semibold hover:tw-bg-gray-50 hover:tw-border-gray-400 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-gray-500 focus:tw-ring-offset-2 tw-transition-all tw-duration-200 tw-flex tw-items-center tw-justify-center" id="cancel-order-btn">
                        <i class="fas fa-arrow-left tw-mr-2"></i>{{ __('productcatalogue::lang.continue_shopping') }}
                    </button>
                    <button type="button" class="tw-flex-1 tw-px-6 tw-py-3 tw-bg-gradient-to-r tw-from-green-500 tw-to-green-600 tw-text-white tw-rounded-xl tw-font-semibold tw-shadow-md hover:tw-shadow-lg hover:tw-from-green-600 hover:tw-to-green-700 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-green-500 focus:tw-ring-offset-2 tw-transition-all tw-duration-200 tw-transform hover:tw-scale-105 tw-flex tw-items-center tw-justify-center" id="send-order-whatsapp-btn">
                        <i class="fab fa-whatsapp tw-mr-2 tw-text-lg"></i> {{ __('productcatalogue::lang.send_order_via_whatsapp') }}
                    </button>
                </div>
            </div>
        </aside>
    </div>
</div>
@endif
@stop
@section('javascript')
<script type="text/javascript">

    var catalogue_enable_whatsapp_ordering = ($('#__enable_whatsapp_ordering').val() == '1');

    (function($) {
    $(document).ready( function() {
        // Initialize currency variables (common.js not included in guest layout)
        if (typeof __currency_symbol === 'undefined') {
            __currency_symbol = $('input#__symbol').val();
            __currency_thousand_separator = $('input#__thousand').val();
            __currency_decimal_separator = $('input#__decimal').val();
            __currency_symbol_placement = $('input#__symbol_placement').val();
            if ($('input#__precision').length > 0) {
                __currency_precision = $('input#__precision').val();
            } else {
                __currency_precision = 2;
            }
        }
        
        __currency_convert_recursively($('.content'));
        
        // Initialize WhatsApp number from backend
        catalogue_cart_whatsapp_number = $('#__whatsapp_number').val() || '';
        
        if (catalogue_enable_whatsapp_ordering) {
            // Initialize cart
            catalogue_init_cart();

            catalogue_update_cart_badge();
            catalogue_display_cart();

            // Sync quantity inputs with cart
            catalogue_sync_quantities_with_cart();

            // Always reset drawer to cart view when closed
            $('#cartDrawer').on('change', function() {
                if (!this.checked) {
                    catalogue_show_cart_drawer_view();
                }
            });
        }
    });

    $(document).on('click', '.show-product-details', function(e){
        e.preventDefault();
        var $link = $(this);
        $.ajax({
            url: $link.data('href'),
            dataType: 'html',
            success: function(result) {
                $('.product_modal')
                    .html(result)
                    .modal('show');
                __currency_convert_recursively($('.product_modal'));
                
                if (catalogue_enable_whatsapp_ordering) {
                    // Sync quantities with cart when modal opens
                    catalogue_update_cart_badge();
                    // Use shown.bs.modal event to ensure modal is fully rendered
                    $('.product_modal').on('shown.bs.modal', function() {
                        catalogue_sync_quantities_with_cart();
                        $(this).off('shown.bs.modal'); // Remove handler after first use
                    });
                }
            },
        });
    });
    
    if (catalogue_enable_whatsapp_ordering) {
        // Handle modal shown event for cart sync
        $(document).on('shown.bs.modal', '.product_modal', function() {
            catalogue_update_cart_badge();
            catalogue_sync_quantities_with_cart();
        });
    }

    $(document).on('click', '.menu', function(e){
        e.preventDefault();
        var cat_id = $(this).attr('href');
        if ($(cat_id).length) {
            var navH = ($('#catalogueNav').outerHeight() || 0);
            $('html, body').animate({
                scrollTop: ($(cat_id).offset().top - navH - 12)
            }, 1000);
        }
    });

    })(jQuery);

    // Sticky fallback: fix the nav once it reaches the top
    var catalogueNavWrapTop = null;
    function catalogue_update_nav_wrap_top() {
        var $wrap = $('#catalogueNavWrap');
        if (!$wrap.length) return;
        // Ensure we measure in non-fixed state
        $wrap.removeClass('is-fixed');
        $('#catalogueNavSpacer').hide().height(0);
        catalogueNavWrapTop = $wrap.offset() ? $wrap.offset().top : null;
    }

    $(function() {
        catalogue_update_nav_wrap_top();
        $(window).on('resize', function() {
            catalogue_update_nav_wrap_top();
        });
    });

    $(window).scroll(function() {
        var height = $(window).scrollTop();
        var $wrap = $('#catalogueNavWrap');
        var $nav = $('#catalogueNav');
        var $spacer = $('#catalogueNavSpacer');

        // If the page layout shifts, recover the measurement lazily
        if (catalogueNavWrapTop === null) {
            catalogue_update_nav_wrap_top();
        }

        if ($wrap.length && catalogueNavWrapTop !== null) {
            if (height >= catalogueNavWrapTop) {
                if (!$wrap.hasClass('is-fixed')) {
                    $wrap.addClass('is-fixed');
                    $spacer.height($wrap.outerHeight() || 0).show();
                }
                $nav.addClass('is-scrolled');
            } else {
                $wrap.removeClass('is-fixed');
                $spacer.hide().height(0);
                $nav.removeClass('is-scrolled');
            }
        }

        if(height  > 180) {
            $('.scrolltop:hidden').stop(true, true).fadeIn();
        } else {
            $('.scrolltop').stop(true, true).fadeOut();
        }
    });

    $(document).on('click', '.scroll', function(e){
        $("html,body").animate({scrollTop:$("#top").offset().top},"1000");
        return false;
    });

    // Cart Management JavaScript - Global variables for shared state
    var catalogue_cart_whatsapp_number = '';
    var catalogue_cart_previous_quantities = {};
    
    // Get cart from localStorage
    function catalogue_get_cart() {
        var cart = localStorage.getItem('product_catalogue_cart');
        return cart ? JSON.parse(cart) : [];
    }
    
    // Save cart to localStorage
    function catalogue_save_cart(cart) {
        localStorage.setItem('product_catalogue_cart', JSON.stringify(cart));
    }
    
    // Get item key for tracking
    function catalogue_get_item_key(productId, variationId) {
        return productId + '_' + variationId;
    }
    
    // Format currency using standard application function
    function catalogue_format_currency(amount) {
        return __currency_trans_from_en(amount, true, false, __currency_precision, false);
    }
    
    // Initialize cart
    function catalogue_init_cart() {
        // Store previous quantities for comparison
        catalogue_cart_previous_quantities = {};
        
        // Event handlers for product cards
        $(document).on('click', '.btn-plus', catalogue_increase_quantity);
        $(document).on('click', '.btn-minus', catalogue_decrease_quantity);
        $(document).on('change', '.product-quantity', catalogue_quantity_change_handler);
        
        // Event handlers for modal (simple products)
        $(document).on('click', '.btn-plus-modal', catalogue_increase_quantity_modal);
        $(document).on('click', '.btn-minus-modal', catalogue_decrease_quantity_modal);
        $(document).on('change', '.product-quantity-modal', catalogue_quantity_change_handler);
        
        // Event handlers for variations in modal
        $(document).on('click', '.btn-plus-variation', catalogue_increase_quantity_variation);
        $(document).on('click', '.btn-minus-variation', catalogue_decrease_quantity_variation);
        $(document).on('change', '.product-quantity-variation', catalogue_quantity_change_handler);
        
        // Cart management handlers
        $(document).on('click', '.remove-cart-item', catalogue_remove_from_cart);
        $(document).on('change', '.cart-item-quantity', catalogue_update_cart_quantity_from_input);
        $(document).on('click', '#place-order-btn', catalogue_show_order_form);
        $(document).on('click', '#back-to-cart-btn', function() {
            catalogue_show_cart_drawer_view();
        });
        $(document).on('click', '#cancel-order-btn', function() {
            catalogue_show_cart_drawer_view();
        });
        $(document).on('click', '#send-order-whatsapp-btn', catalogue_send_order_via_whatsapp);
        
        // Initialize previous quantities
        catalogue_init_previous_quantities();
    }
    
    // Initialize previous quantities from cart
    function catalogue_init_previous_quantities() {
        var cart = catalogue_get_cart();
        catalogue_cart_previous_quantities = {};
        
        cart.forEach(function(item) {
            var key = catalogue_get_item_key(item.product_id, item.variation_id);
            catalogue_cart_previous_quantities[key] = item.quantity;
        });
    }
    
    // Sync quantity inputs with cart
    function catalogue_sync_quantities_with_cart() {
        var cart = catalogue_get_cart();
        
        // Update all quantity inputs based on cart
        $('.product-quantity, .product-quantity-modal, .product-quantity-variation').each(function() {
            var $input = $(this);
            var productId = $input.data('product-id');
            var variationId = $input.data('variation-id');
            
            // Find matching item in cart
            var cartItem = cart.find(function(item) {
                return item.product_id == productId && item.variation_id == variationId;
            });
            
            if (cartItem) {
                $input.val(cartItem.quantity);
                var key = catalogue_get_item_key(productId, variationId);
                catalogue_cart_previous_quantities[key] = cartItem.quantity;
            } else {
                $input.val(0);
                var key = catalogue_get_item_key(productId, variationId);
                catalogue_cart_previous_quantities[key] = 0;
            }
        });
    }
    
    // Auto update cart based on quantity change
    function catalogue_auto_update_cart($input) {
        var productId = $input.data('product-id');
        var variationId = $input.data('variation-id');
        var productName = $input.data('product-name') || '';
        var variationName = $input.data('variation-name') || '';
        var price = __num_uf($input.data('price')) || 0;
        var image = $input.data('image') || '';
        var sku = $input.data('sku') || '';
        
        var currentQuantity = parseInt($input.val()) || 0;
        var key = catalogue_get_item_key(productId, variationId);
        var previousQuantity = catalogue_cart_previous_quantities[key] || 0;
        
        // If quantity decreased to 0, remove from cart
        if (currentQuantity === 0 && previousQuantity > 0) {
            catalogue_remove_item_from_cart(productId, variationId);
            catalogue_cart_previous_quantities[key] = 0;
            return;
        }
        
        // If quantity is > 0, add or update cart
        if (currentQuantity > 0) {
            var cart = catalogue_get_cart();
            var found = false;
            
            // Check if item already exists in cart
            for (var i = 0; i < cart.length; i++) {
                if (cart[i].product_id == productId && cart[i].variation_id == variationId) {
                    // Update quantity directly (don't add)
                    cart[i].quantity = currentQuantity;
                    cart[i].product_name = productName;
                    cart[i].variation_name = variationName;
                    cart[i].price = price;
                    cart[i].image_url = image;
                    cart[i].sku = sku;
                    found = true;
                    break;
                }
            }
            
            // If not found, add new item
            if (!found) {
                cart.push({
                    product_id: productId,
                    variation_id: variationId,
                    product_name: productName,
                    variation_name: variationName,
                    price: price,
                    quantity: currentQuantity,
                    image_url: image,
                    sku: sku
                });
            }
            
            catalogue_save_cart(cart);
            catalogue_update_cart_badge();
            catalogue_display_cart();
        }
        
        // Update previous quantity
        catalogue_cart_previous_quantities[key] = currentQuantity;
    }
    
    // Remove item from cart by product and variation
    function catalogue_remove_item_from_cart(productId, variationId) {
        var cart = catalogue_get_cart();
        var newCart = cart.filter(function(item) {
            return !(item.product_id == productId && item.variation_id == variationId);
        });
        catalogue_save_cart(newCart);
        catalogue_update_cart_badge();
        catalogue_display_cart();
    }
    
    // Increase quantity (product cards)
    function catalogue_increase_quantity(e) {
        e.preventDefault();
        var $btn = $(e.currentTarget);
        var $input = $btn.closest('.input-group').find('.product-quantity');
        var currentVal = parseInt($input.val()) || 0;
        $input.val(currentVal + 1);
        catalogue_auto_update_cart($input);
    }
    
    // Decrease quantity (product cards)
    function catalogue_decrease_quantity(e) {
        e.preventDefault();
        var $btn = $(e.currentTarget);
        var $input = $btn.closest('.input-group').find('.product-quantity');
        var currentVal = parseInt($input.val()) || 0;
        if (currentVal > 0) {
            $input.val(currentVal - 1);
            catalogue_auto_update_cart($input);
        }
    }
    
    // Increase quantity modal (simple products)
    function catalogue_increase_quantity_modal(e) {
        e.preventDefault();
        var $btn = $(e.currentTarget);
        var $input = $btn.closest('.input-group').find('.product-quantity-modal');
        var currentVal = parseInt($input.val()) || 0;
        $input.val(currentVal + 1);
        catalogue_auto_update_cart($input);
    }
    
    // Decrease quantity modal (simple products)
    function catalogue_decrease_quantity_modal(e) {
        e.preventDefault();
        var $btn = $(e.currentTarget);
        var $input = $btn.closest('.input-group').find('.product-quantity-modal');
        var currentVal = parseInt($input.val()) || 0;
        if (currentVal > 0) {
            $input.val(currentVal - 1);
            catalogue_auto_update_cart($input);
        }
    }
    
    // Increase quantity variation
    function catalogue_increase_quantity_variation(e) {
        e.preventDefault();
        var $btn = $(e.currentTarget);
        var $input = $btn.closest('.input-group').find('.product-quantity-variation');
        var currentVal = parseInt($input.val()) || 0;
        $input.val(currentVal + 1);
        catalogue_auto_update_cart($input);
    }
    
    // Decrease quantity variation
    function catalogue_decrease_quantity_variation(e) {
        e.preventDefault();
        var $btn = $(e.currentTarget);
        var $input = $btn.closest('.input-group').find('.product-quantity-variation');
        var currentVal = parseInt($input.val()) || 0;
        if (currentVal > 0) {
            $input.val(currentVal - 1);
            catalogue_auto_update_cart($input);
        }
    }
    
    // Quantity change handler
    function catalogue_quantity_change_handler(e) {
        var $input = $(e.currentTarget);
        var val = parseInt($input.val()) || 0;
        if (val < 0) {
            $input.val(0);
        }
        // Auto update cart based on quantity change
        catalogue_auto_update_cart($input);
    }
    
    // Calculate cart total
    function catalogue_calculate_cart_total() {
        var cart = catalogue_get_cart();
        var total = 0;
        
        for (var i = 0; i < cart.length; i++) {
            var price = __num_uf(cart[i].price) || 0;
            var quantity = parseInt(cart[i].quantity) || 0;
            total += price * quantity;
        }
        
        return total;
    }
    
    // Get cart item count
    function catalogue_get_cart_item_count() {
        var cart = catalogue_get_cart();
        var count = 0;
        
        for (var i = 0; i < cart.length; i++) {
            count += parseInt(cart[i].quantity) || 0;
        }
        
        return count;
    }
    
    // Update cart total amount display in navbar
    function catalogue_update_cart_total_display() {
        var total = catalogue_calculate_cart_total();
        var $totalDisplay = $('#cart-total-amount');
        
        if (total > 0) {
            $totalDisplay.text(catalogue_format_currency(total)).show();
        } else {
            $totalDisplay.hide();
        }
    }
    
    // Update cart badge
    function catalogue_update_cart_badge() {
        var count = catalogue_get_cart_item_count();
        var $badge = $('#cart-badge');
        
        if (count > 0) {
            $badge.text(count).show();
        } else {
            $badge.hide();
        }
        
        // Update cart total amount display
        catalogue_update_cart_total_display();
    }
    
    // Display cart
    function catalogue_display_cart() {
        var cart = catalogue_get_cart();
        var $container = $('#cart-items-container');
        var $summary = $('#cart-summary');
        var $footer = $('#cart-footer');
        var defaultImg = "{{ asset('/img/default.png') }}";
        
        if (cart.length === 0) {
            $container.html('<div class="tw-text-center tw-py-12"><i class="fas fa-shopping-cart tw-text-6xl tw-text-gray-300 tw-mb-4"></i><p class="tw-text-gray-500 tw-text-lg tw-font-medium">' + LANG.productcatalogue_your_cart_is_empty + '</p></div>');
            $summary.hide();
            $footer.hide();
            return;
        }
        
        // Build cart items HTML (table layout - mobile friendly)
        var html = '<div class="tw-overflow-x-auto">';
        html += '<table class="table tw-w-full">';
        html += '<thead><tr class="tw-bg-gray-100 tw-border-b-2 tw-border-gray-300">';
        html += '<th class="tw-px-4 tw-py-3 tw-text-left tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase">' + (LANG.productcatalogue_product || 'Product') + '</th>';
        html += '<th class="tw-px-4 tw-py-3 tw-text-center tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase">' + (LANG.productcatalogue_quantity || 'Qty') + '</th>';
        html += '<th class="tw-px-4 tw-py-3 tw-text-right tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase tw-hidden sm:tw-table-cell">' + (LANG.productcatalogue_price || 'Price') + '</th>';
        html += '<th class="tw-px-4 tw-py-3 tw-text-right tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase">' + (LANG.productcatalogue_subtotal_label || 'Subtotal') + '</th>';
        html += '<th class="tw-px-4 tw-py-3 tw-text-right tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase"> ' + (LANG.productcatalogue_action || 'Remove') + '</th>';
        html += '</tr></thead>';
        html += '<tbody class="tw-divide-y tw-divide-gray-200">';

        for (var i = 0; i < cart.length; i++) {
            var item = cart[i];
            var price = __num_uf(item.price) || 0;
            var quantity = parseInt(item.quantity) || 0;
            var subtotal = price * quantity;

            var displayName = item.product_name || '';
            if (item.variation_name) {
                displayName += ' - ' + item.variation_name;
            }

            html += '<tr class="hover:tw-bg-gray-50 tw-transition-colors">';

            // Product cell (image + name + sku)
            html += '<td class="tw-px-4 tw-py-3 tw-align-top">';
            html += '<div class="tw-flex tw-gap-3 tw-items-start">';
            var imageUrl = item.image_url || defaultImg;
            html += '<div class="tw-w-12 tw-h-12 tw-bg-gray-100 tw-rounded-lg tw-border tw-border-gray-200 tw-overflow-hidden tw-flex tw-items-center tw-justify-center tw-flex-shrink-0">';
            html += '<img src="' + imageUrl + '" class="tw-w-full tw-h-full tw-object-contain tw-p-1" alt="' + displayName + '" onerror="this.onerror=null;this.src=\'' + defaultImg + '\';">';
            html += '</div>';
            html += '<div class="tw-min-w-0">';
            html += '<div class="tw-text-gray-900 tw-font-medium tw-leading-snug tw-break-words">' + displayName + '</div>';
            if (item.sku) {
                html += '<div class="tw-text-xs tw-text-gray-500 tw-mt-1"><span class="tw-font-semibold">' + (LANG.productcatalogue_sku || 'SKU') + ':</span> ' + item.sku + '</div>';
            }
            // On xs: show unit price under name to avoid squished columns
            html += '<div class="tw-text-xs tw-text-gray-600 tw-mt-1 sm:tw-hidden"><span class="tw-font-semibold">' + (LANG.productcatalogue_price || 'Price') + ':</span> ' + catalogue_format_currency(price) + '</div>';
            html += '</div>';
            html += '</div>';
            html += '</td>';

            // Quantity cell (controls)
            html += '<td class="tw-px-4 tw-py-3 tw-align-top">';
            html += '<div class="tw-flex tw-justify-center">';
            html += '<div class="input-group tw-inline-flex tw-items-stretch tw-gap-0 tw-bg-gradient-to-r tw-from-gray-50 tw-to-gray-100 tw-rounded-xl tw-p-1 tw-border-2 tw-border-gray-200 tw-shadow-sm">';
            html += '<button class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-bg-white tw-text-gray-700 tw-border-2 tw-border-gray-300 tw-border-r-0 tw-rounded-l-xl hover:tw-bg-primary-500 hover:tw-text-white hover:tw-border-primary-500 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 tw-transition-all tw-font-bold tw-text-base tw-flex-shrink-0" type="button" onclick="catalogue_decrease_cart_quantity(' + i + ')"><i class="fas fa-minus tw-text-xs"></i></button>';
            html += '<input type="number" class="cart-item-quantity tw-w-16 tw-h-10 tw-text-center tw-font-bold tw-text-gray-900 tw-bg-white tw-border-2 tw-border-gray-300 tw-border-x-0 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 focus:tw-border-primary-500 tw-text-base tw-appearance-none tw-flex-shrink-0" value="' + item.quantity + '" min="0" data-index="' + i + '">';
            html += '<button class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-bg-white tw-text-gray-700 tw-border-2 tw-border-gray-300 tw-border-l-0 tw-rounded-r-xl hover:tw-bg-primary-500 hover:tw-text-white hover:tw-border-primary-500 focus:tw-outline-none focus:tw-ring-2 focus:tw-ring-primary-500 tw-transition-all tw-font-bold tw-text-base tw-flex-shrink-0" type="button" onclick="catalogue_increase_cart_quantity(' + i + ')"><i class="fas fa-plus tw-text-xs"></i></button>';
            html += '</div>';
            html += '</div>';
            html += '</td>';

            // Price cell (sm+)
            html += '<td class="tw-px-4 tw-py-3 tw-text-right tw-align-top tw-text-gray-700 tw-hidden sm:tw-table-cell">';
            html += catalogue_format_currency(price);
            html += '</td>';

            // Subtotal cell
            html += '<td class="tw-px-4 tw-py-3 tw-text-right tw-align-top tw-text-gray-900 tw-font-bold">';
            html += catalogue_format_currency(subtotal);
            html += '</td>';

            // Remove cell
            html += '<td class="tw-px-4 tw-py-3 tw-text-right tw-align-top">';
            html += '<button class="tw-inline-flex tw-items-center tw-justify-center tw-w-10 tw-h-10 tw-text-red-500 hover:tw-bg-red-50 hover:tw-text-red-700 tw-rounded-lg tw-transition-all remove-cart-item" data-index="' + i + '" title="Remove"><i class="fas fa-trash tw-text-base"></i></button>';
            html += '</td>';

            html += '</tr>';
        }

        html += '</tbody></table></div>';
        $container.html(html);
        
        // Update summary
        var total = catalogue_calculate_cart_total();
        $('#cart-subtotal').text(catalogue_format_currency(total));
        $('#cart-total').text(catalogue_format_currency(total));
        
        $summary.show();
        $footer.show();
    }
    
    // Increase cart quantity (for cart modal)
    function catalogue_increase_cart_quantity(index) {
        var cart = catalogue_get_cart();
        if (index >= 0 && index < cart.length) {
            var item = cart[index];
            item.quantity += 1;
            var key = catalogue_get_item_key(item.product_id, item.variation_id);
            catalogue_cart_previous_quantities[key] = item.quantity;
            catalogue_save_cart(cart);
            catalogue_update_cart_badge();
            catalogue_display_cart();
            catalogue_sync_quantities_with_cart();
        }
    }
    
    // Decrease cart quantity (for cart modal)
    function catalogue_decrease_cart_quantity(index) {
        var cart = catalogue_get_cart();
        if (index < 0 || index >= cart.length) return;
        var item = cart[index];
        if (item.quantity > 1) {
            item.quantity -= 1;
            var key = catalogue_get_item_key(item.product_id, item.variation_id);
            catalogue_cart_previous_quantities[key] = item.quantity;
            catalogue_save_cart(cart);
            catalogue_update_cart_badge();
            catalogue_display_cart();
            catalogue_sync_quantities_with_cart();
        } else {
            // Quantity is 1: confirm before removing item
            swal({
                title: '',
                text: LANG.productcatalogue_confirm_remove_from_cart,
                icon: 'warning',
                buttons: true,
                dangerMode: true,
            }).then(function(confirmed) {
                if (!confirmed) return;
                cart.splice(index, 1);
                var key = catalogue_get_item_key(item.product_id, item.variation_id);
                catalogue_cart_previous_quantities[key] = 0;
                catalogue_save_cart(cart);
                catalogue_update_cart_badge();
                catalogue_display_cart();
                catalogue_sync_quantities_with_cart();
            });
        }
    }
    
    // Update cart quantity from input change
    function catalogue_update_cart_quantity_from_input(e) {
        var index = parseInt($(e.currentTarget).data('index')) || 0;
        var quantity = parseInt($(e.currentTarget).val()) || 0;
        
        var cart = catalogue_get_cart();
        if (index >= 0 && index < cart.length) {
            var item = cart[index];
            
            if (quantity <= 0) {
                // Remove item if quantity is 0
                cart.splice(index, 1);
                var key = catalogue_get_item_key(item.product_id, item.variation_id);
                catalogue_cart_previous_quantities[key] = 0;
            } else {
                // Update quantity
                cart[index].quantity = quantity;
                var key = catalogue_get_item_key(item.product_id, item.variation_id);
                catalogue_cart_previous_quantities[key] = quantity;
            }
            
            catalogue_save_cart(cart);
            catalogue_update_cart_badge();
            catalogue_display_cart();
            catalogue_sync_quantities_with_cart();
        }
    }
    
    // Remove item from cart
    function catalogue_remove_from_cart(e) {
        e.preventDefault();
        var index = $(e.currentTarget).data('index');
        var cart = catalogue_get_cart();
        if (index < 0 || index >= cart.length) return;

        swal({
            title: '',
            text: LANG.productcatalogue_confirm_remove_from_cart,
            icon: 'warning',
            buttons: true,
            dangerMode: true,
        }).then(function(confirmed) {
            if (!confirmed) return;
            var removedItem = cart[index];
            cart.splice(index, 1);
            if (removedItem) {
                var key = catalogue_get_item_key(removedItem.product_id, removedItem.variation_id);
                catalogue_cart_previous_quantities[key] = 0;
            }
            catalogue_save_cart(cart);
            catalogue_update_cart_badge();
            catalogue_display_cart();
            catalogue_sync_quantities_with_cart();
        });
    }
    
    // Show order form (Step 3)
    function catalogue_show_order_form() {
        var cart = catalogue_get_cart();
        
        if (cart.length === 0) {
            swal({
                title: '',
                    text: LANG.productcatalogue_cart_empty,
                icon: 'warning',
                buttons: {
                    confirm: {
                        text: 'OK',
                        value: true,
                        visible: true,
                        className: '',
                        closeModal: true
                    }
                }
            });
            return;
        }
        
        // Populate order summary
        catalogue_populate_order_summary();

        // Switch drawer view to order form
        catalogue_show_order_drawer_view();
    }

    function catalogue_show_cart_drawer_view() {
        $('#order-drawer-view').addClass('tw-hidden');
        $('#cart-drawer-view').removeClass('tw-hidden');
    }

    function catalogue_show_order_drawer_view() {
        $('#cart-drawer-view').addClass('tw-hidden');
        $('#order-drawer-view').removeClass('tw-hidden');

        // Scroll order view to top
        var $orderScroll = $('#order-drawer-view').find('.tw-overflow-y-auto').first();
        if ($orderScroll.length) {
            $orderScroll.scrollTop(0);
        }
    }
    
    // Populate order summary in order form
    function catalogue_populate_order_summary() {
        var cart = catalogue_get_cart();
        var html = '<div class="tw-overflow-x-auto">';
        html += '<table class="table tw-w-full">';
        html += '<thead><tr class="tw-bg-gray-100 tw-border-b-2 tw-border-gray-300">';
        html += '<th class="tw-px-4 tw-py-3 tw-text-left tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase">' + LANG.productcatalogue_product + '</th>';
        html += '<th class="tw-px-4 tw-py-3 tw-text-center tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase">' + LANG.productcatalogue_quantity + '</th>';
        html += '<th class="tw-px-4 tw-py-3 tw-text-right tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase">' + LANG.productcatalogue_price + '</th>';
        html += '<th class="tw-px-4 tw-py-3 tw-text-right tw-text-sm tw-font-bold tw-text-gray-700 tw-uppercase">' + LANG.productcatalogue_subtotal_label + '</th>';
        html += '</tr></thead>';
        html += '<tbody class="tw-divide-y tw-divide-gray-200">';
        
        for (var i = 0; i < cart.length; i++) {
            var item = cart[i];
            var price = __num_uf(item.price) || 0;
            var quantity = parseInt(item.quantity) || 0;
            var subtotal = price * quantity;
            var displayName = item.product_name || '';
            if (item.variation_name) {
                displayName += ' - ' + item.variation_name;
            }
            
            html += '<tr class="hover:tw-bg-gray-50 tw-transition-colors">';
            html += '<td class="tw-px-4 tw-py-3 tw-text-gray-900 tw-font-medium">' + displayName + '</td>';
            html += '<td class="tw-px-4 tw-py-3 tw-text-center tw-text-gray-700 tw-font-semibold">' + quantity + '</td>';
            html += '<td class="tw-px-4 tw-py-3 tw-text-right tw-text-gray-700">' + catalogue_format_currency(price) + '</td>';
            html += '<td class="tw-px-4 tw-py-3 tw-text-right tw-text-gray-900 tw-font-bold">' + catalogue_format_currency(subtotal) + '</td>';
            html += '</tr>';
        }
        
        html += '</tbody></table>';
        html += '</div>';
        $('#order-summary-items').html(html);
        
        // Update total
        var total = catalogue_calculate_cart_total();
        $('#order-total-display').text(catalogue_format_currency(total));
    }
    
    // Generate 5-digit order ID
    function catalogue_generate_order_id() {
        // Generate a random 5-digit number (10000 to 99999)
        var orderId = Math.floor(10000 + Math.random() * 90000);
        return orderId.toString();
    }
    
    // Generate WhatsApp link with order details
    function catalogue_generate_whatsapp_link(customerData) {
        var cart = catalogue_get_cart();
        var whatsappNumber = catalogue_cart_whatsapp_number || $('#__whatsapp_number').val() || '';
        
        if (!whatsappNumber) {
            swal({
                title: '',
                text: LANG.productcatalogue_whatsapp_not_configured,
                icon: 'error',
                buttons: {
                    confirm: {
                        text: 'OK',
                        value: true,
                        visible: true,
                        className: '',
                        closeModal: true
                    }
                }
            });
            return null;
        }
        
        // Format WhatsApp number (remove any non-numeric characters except +)
        whatsappNumber = whatsappNumber.replace(/[^\d+]/g, '');
        
        // Generate 5-digit order ID
        var orderId = catalogue_generate_order_id();
        
        // Build order message with structured design
        var message = '*New Order*\n\n';
        
        // Order ID
        message += 'Order ID: ' + orderId + '\n\n';
        
        // Order Items
        message += '*Order Items:*\n';
        for (var i = 0; i < cart.length; i++) {
            var item = cart[i];
            var price = __num_uf(item.price) || 0;
            var quantity = parseInt(item.quantity) || 0;
            var subtotal = price * quantity;
            var displayName = item.product_name || '';
            if (item.variation_name) {
                displayName += ' - ' + item.variation_name;
            }
            
            var serialNumber = (i + 1); // Serial number starting from 1
            message += serialNumber + '. ' + displayName + '\n';
            message += '   Quantity: ' + quantity + ' × Price: ' + catalogue_format_currency(price) + ' = ' + catalogue_format_currency(subtotal) + '\n\n';
        }
        
        // Total
        var total = catalogue_calculate_cart_total();
        message += '*Total: ' + catalogue_format_currency(total) + '*\n\n';
        
        // Customer Details
        message += '*Customer Details:*\n';
        message += 'Name: ' + customerData.name + '\n';
        message += 'Email: ' + customerData.email + '\n';
        message += 'Phone: ' + customerData.phone + '\n';
        message += 'Delivery Address: ' + customerData.address;
        
        // Generate WhatsApp URL
        var whatsappUrl = 'https://wa.me/' + whatsappNumber + '?text=' + encodeURIComponent(message);
        
        return whatsappUrl;
    }
    
    // Send order via WhatsApp
    function catalogue_send_order_via_whatsapp() {
        // Use HTML5 validation - check if form is valid
        var form = document.getElementById('order-form');
        if (!form.checkValidity()) {
            // Find first invalid field and show custom message
            var firstInvalid = form.querySelector(':invalid');
            if (firstInvalid) {
                firstInvalid.focus();
                var fieldName = firstInvalid.getAttribute('name');
                var message = '';
                
                switch(fieldName) {
                    case 'customer_name':
                        message = LANG.productcatalogue_please_enter_name;
                            break;
                        case 'customer_email':
                            if (firstInvalid.validity.typeMismatch) {
                                message = LANG.productcatalogue_please_enter_valid_email;
                            } else {
                                message = LANG.productcatalogue_please_enter_email;
                            }
                            break;
                        case 'customer_phone':
                            message = LANG.productcatalogue_please_enter_phone;
                            break;
                        case 'delivery_address':
                            message = LANG.productcatalogue_please_enter_address;
                        break;
                    default:
                        message = firstInvalid.validationMessage;
                }
                
                swal({
                    title: '',
                    text: message,
                    icon: 'warning',
                    buttons: {
                        confirm: {
                            text: 'OK',
                            value: true,
                            visible: true,
                            className: '',
                            closeModal: true
                        }
                    }
                });
            }
            // Trigger HTML5 validation display
            form.reportValidity();
            return;
        }
        
        // Get form values
        var customerName = $('#customer_name').val().trim();
        var customerEmail = $('#customer_email').val().trim();
        var customerPhone = $('#customer_phone').val().trim();
        var deliveryAddress = $('#delivery_address').val().trim();
        
        // Prepare customer data
        var customerData = {
            name: customerName,
            email: customerEmail,
            phone: customerPhone,
            address: deliveryAddress
        };

        var orderUrl = $('#__catalogue_order_url').val();
        if (!orderUrl) {
            swal({
                title: '',
                text: 'Order URL is not configured.',
                icon: 'error'
            });
            return;
        }

        var cart = catalogue_get_cart();
        var submitPayload = {
            _token: $('#__catalogue_csrf_token').val() || $('meta[name="csrf-token"]').attr('content'),
            customer_name: customerName,
            customer_email: customerEmail,
            customer_phone: customerPhone,
            delivery_address: deliveryAddress,
            products: cart.map(function(item) {
                return {
                    product_id: item.product_id,
                    variation_id: item.variation_id,
                    quantity: parseInt(item.quantity) || 0
                };
            })
        };

        var whatsappWindow = null;
        if (catalogue_cart_whatsapp_number || $('#__whatsapp_number').val()) {
            whatsappWindow = window.open('about:blank', '_blank');
        }

        var $button = $('#send-order-whatsapp-btn');
        var originalHtml = $button.html();
        $button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin tw-mr-2"></i> Processing...');

        $.ajax({
            method: 'POST',
            url: orderUrl,
            data: submitPayload,
            success: function(response) {
                if (whatsappWindow) {
                    if (response.whatsapp_url) {
                        whatsappWindow.location = response.whatsapp_url;
                    } else {
                        whatsappWindow.close();
                    }
                }

                $('#cartDrawer').prop('checked', false);
                catalogue_show_cart_drawer_view();
                catalogue_save_cart([]);
                catalogue_cart_previous_quantities = {};
                catalogue_sync_quantities_with_cart();
                catalogue_update_cart_badge();
                catalogue_display_cart();
                $('#order-form')[0].reset();

                var successText = 'Order request ' + (response.invoice_no || '') + ' created successfully.';
                if (response.login_created && response.username && response.password) {
                    successText += '\n\nLogin URL: ' + (response.login_url || $('#__catalogue_login_url').val());
                    successText += '\nUsername: ' + response.username;
                    successText += '\nPassword: ' + response.password;
                    successText += '\nTrack orders: ' + (response.dashboard_url || $('#__catalogue_dashboard_url').val());
                } else if (response.username) {
                    successText += '\n\nTrack orders: ' + (response.dashboard_url || $('#__catalogue_dashboard_url').val());
                    successText += '\nLogin URL: ' + (response.login_url || $('#__catalogue_login_url').val());
                    successText += '\nUsername: ' + response.username;
                }

                if (!response.whatsapp_url) {
                    successText += '\n\nWhatsApp sending is not configured, but the order request was saved.';
                }

                swal({
                    title: '',
                    text: successText,
                    icon: 'success',
                    buttons: {
                        confirm: {
                            text: 'OK',
                            value: true,
                            visible: true,
                            className: '',
                            closeModal: true
                        }
                    }
                });
            },
            error: function(xhr) {
                if (whatsappWindow) {
                    whatsappWindow.close();
                }

                var message = 'Unable to create order request.';
                if (xhr.responseJSON) {
                    if (xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    if (xhr.responseJSON.errors) {
                        var firstKey = Object.keys(xhr.responseJSON.errors)[0];
                        if (firstKey && xhr.responseJSON.errors[firstKey] && xhr.responseJSON.errors[firstKey][0]) {
                            message = xhr.responseJSON.errors[firstKey][0];
                        }
                    }
                }

                swal({
                    title: '',
                    text: message,
                    icon: 'error',
                    buttons: {
                        confirm: {
                            text: 'OK',
                            value: true,
                            visible: true,
                            className: '',
                            closeModal: true
                        }
                    }
                });
            },
            complete: function() {
                $button.prop('disabled', false).html(originalHtml);
            }
        });
    }

</script>
@endsection