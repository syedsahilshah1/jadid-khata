<?php

return [
    'name' => 'ProductCatalogue',
    'module_version' => '3.0',
    'pid' => 8,
];
